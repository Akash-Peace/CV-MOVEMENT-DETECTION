## dinoaircontroller

dinoaircontroller is the air controller used to control the key functions of chrome's dino game with a hand movement.

Game link: chrome://dino/

